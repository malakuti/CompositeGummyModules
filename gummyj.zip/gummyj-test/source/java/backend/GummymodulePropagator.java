package backend;


/**
 * @desc gummymodule, that simply propagates the received event
 * @author fenris
 */
public class GummymodulePropagator extends Gummymodule
{
	public GummymodulePropagator()
	{
		super();
		this.set_name("propagator");
	}
	
	public void process(Gummyevent event)
	{
		this.show_status(event);
		this.spread(event);
	}
}

