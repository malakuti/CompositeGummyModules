package backend;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;


/**
 * @desc interface for handling an event
 * @author fenris
 */
public abstract class Processor implements Runnable
{
	public static boolean blocking = false;
	
	private boolean destructing;
	private Queue<Gummyevent> queue;
	private Thread thread;
	
	public Processor(boolean autostart)
	{
		this.destructing = false;
		this.queue = new LinkedBlockingQueue<Gummyevent>();
		this.thread = null;
		
		if (! Processor.blocking)
		{
			this.thread = new Thread(this);
			if (autostart) this.thread.start();
		}
	}
	
	public Processor()
	{
		this(true);
	}
	
	public boolean get_destructing()
	{
		return this.destructing;
	}
	
	public synchronized void enqueue(Gummyevent event)
	{
		if (Processor.blocking)
		{
			this.process(event);
		}
		else
		{
			this.queue.add(event);
		}
	}
	
	protected void destruct()
	{
		this.destructing = true;
	}
	
	protected abstract void process(Gummyevent event);
	
	public void run()
	{
		while (! this.destructing)
		{
			if (! this.queue.isEmpty())
			{
				Gummyevent event = this.queue.remove();
				this.process(event);
			}
		}
	}
}

