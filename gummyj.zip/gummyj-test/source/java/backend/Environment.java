package backend;


/**
 * @desc class providing the environment for event-processing
 * @author fenris
 */
public class Environment
{
	private GummymodulePrimitive main;
	private Thread thread;
	public int verbosity;
	
	protected Environment()
	{
		this.main = (GummymodulePrimitive)((new GummymodulePrimitive(false)).set_name("environment"));
		this.thread = null;
		this.verbosity = 0;
	}
	
	/**
	 * @desc adds a module to the environment
	 * @author fenris
	 */
	public void insert(Gummymodule module)
	{
		this.main.add_eventmethod(module);
	}
	
	/**
	 * @desc makes the environment process an event
	 * @author fenris
	 */
	public void notify(Gummyevent event)
	{
		this.main.enqueue(event);
	}
	
	/**
	 * @desc starts the environment
	 * @author fenris
	 */
	public void start()
	{
		if (this.verbosity >= 1) System.out.println("# start");
		this.thread = new Thread(this.main);
		this.thread.start();
	}
	
	/**
	 * @desc puts the processing asleep for a given amount of time
	 * @author fenris
	 */
	public void wait(int milliseconds)
	{
		if (this.verbosity >= 1) System.out.println("# wait");
		try
		{
			this.thread.sleep(milliseconds);
		}
		catch (InterruptedException exception)
		{
			System.err.println("interrupted");
			exception.printStackTrace();
		}
	}
	
	/**
	 * @desc stops the environment
	 * @author fenris
	 */
	public void stop()
	{
		if (this.verbosity >= 1) System.out.println("# stop");
		this.main.destruct();
	}
	
	public static Environment instance;
	
	/**
	 * @desc creates the singleton-instance if necessary and returns it
	 * @author fenris
	 */
	public static Environment get_instance()
	{
		if (Environment.instance == null) Environment.instance = new Environment();
		return Environment.instance;
	}
}

