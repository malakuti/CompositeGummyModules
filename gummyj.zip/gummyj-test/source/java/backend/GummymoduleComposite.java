package backend;

import java.util.List;
import java.util.LinkedList;


/**
 * @desc gummymodule with complex structure
 * @author fenris
 */
public class GummymoduleComposite extends Gummymodule
{
	private List<Gummymodule> selectors;
	private List<Gummymodule> reactors;
	private List<Gummymodule> publishers;
	
	public GummymoduleComposite(boolean autostart)
	{
		super(autostart);
		this.selectors = new LinkedList<Gummymodule>();
		this.reactors = new LinkedList<Gummymodule>();
		this.publishers = new LinkedList<Gummymodule>();
	}
	
	public GummymoduleComposite()
	{
		this(true);
	}
	
	private void update_targets()
	{
		for (Gummymodule selector : this.selectors)
		{
			selector.targets = new LinkedList<Processor>();
			for (Gummymodule target : this.reactors) selector.add_target(target);
			// for (Gummymodule target : this.publishers) selector.add_target(target);
		}
		for (Gummymodule reactor : this.reactors)
		{
			reactor.targets = new LinkedList<Processor>();
			for (Gummymodule target : this.reactors) reactor.add_target(target);
			for (Gummymodule target : this.publishers) reactor.add_target(target);
		}
		for (Gummymodule publisher : this.publishers)
		{
			publisher.targets = this.targets;
		}
	}
	
	public void add_selector(Gummymodule selector)
	{
		selector.parent = this;
		selector.name = "selector" + ((selector.name == null) ? "" : (":" + selector.name));
		this.selectors.add(selector);
		this.update_targets();
	}
	
	public void add_reactor(Gummymodule reactor)
	{
		reactor.parent = this;
		reactor.name = "reactor" + ((reactor.name == null) ? "" : (":" + reactor.name));
		this.reactors.add(reactor);
		this.update_targets();
	}
	
	public void add_publisher(Gummymodule publisher)
	{
		publisher.parent = this;
		publisher.name = "publisher" + ((publisher.name == null) ? "" : (":" + publisher.name));
		this.publishers.add(publisher);
		this.update_targets();
	}
	
	public void process(Gummyevent event)
	{
		this.show_status(event);
		for (Gummymodule selector : this.selectors) selector.enqueue(event);
	}
		
	public void destruct()
	{
		super.destruct();
		for (Gummymodule selector : this.selectors) selector.destruct();
		for (Gummymodule reactor : this.reactors) reactor.destruct();
		for (Gummymodule publisher : this.publishers) publisher.destruct();
	}
}

