package backend;


/**
 * @desc gummymodule for representing an eventmethod
 * @author fenris
 */
public abstract class GummymoduleEventmethod extends Gummymodule
{
	public GummymoduleEventmethod()
	{
		super();
	}
	
	protected abstract boolean condition(Gummyevent event) throws Exception;
	
	protected abstract void action(Gummyevent event, Gummymodule self) throws Exception;
	
	public void process(Gummyevent event)
	{
		try
		{
			if (this.condition(event)) this.action(event, this.parent);
		}
		catch (Exception exception)
		{
			System.err.println("error processing eventmethod");
			exception.printStackTrace();
		}
	}
}


