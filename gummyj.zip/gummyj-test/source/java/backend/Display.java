package backend;


/**
 * @desc output the events to the console for processing them
 * @author fenris
 */
public class Display extends Processor
{
	private String prefix;
	
	public Display(String prefix)
	{
		super();
		this.prefix = prefix;
	}
	
	public Display()
	{
		this(">>> ");
	}
	
	protected void process(Gummyevent event)
	{
		System.out.println(this.prefix + event.toString());
	}
	
	public void destruct()
	{
		super.destruct();
	}
	
	public String toString()
	{
		return "{Display}";
	}
}

