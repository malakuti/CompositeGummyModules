package backend;


/**
 * @desc gummymodule with simple structure
 * @author fenris
 */
public class GummymodulePrimitive extends GummymoduleComposite
{
	public GummymodulePrimitive(boolean autostart)
	{
		super(autostart);
		this.add_selector(new GummymodulePropagator().set_name("push-in"));
		this.add_publisher(new GummymodulePropagator().set_name("push-out"));
	}
	
	public GummymodulePrimitive()
	{
		this(true);
	}
	
	public void add_eventmethod(Gummymodule eventmethod)
	{
		// this.parent = this;
		eventmethod.name = "eventmethod" + ((eventmethod.name == null) ? "" : (":" + eventmethod.name));
		this.add_reactor(eventmethod);
	}	
}

