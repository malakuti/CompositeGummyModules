package backend;


/**
 * @desc gummymodule, that simply spawns a fixed event if it receives any event
 * @author fenris
 */
public class GummymoduleAggregator extends Gummymodule
{
	private Gummyevent output;
	
	public GummymoduleAggregator(Gummyevent output)
	{
		super();
		this.output = output;
		this.set_name("aggregator");
	}
	
	public void process(Gummyevent event)
	{
		this.show_status(event);
		if (event.getClass().isAssignableFrom(this.output.getClass())) this.spread(output);
	}
}

