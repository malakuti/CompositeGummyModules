package backend;

import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;


/**
 * @desc abstract base class for Gummymodules
 * @author fenris
 */
public abstract class Gummymodule extends Processor
{
	public static int verbosity = 0;
	
	protected List<Processor> targets;
	protected Gummymodule parent;
	protected String name;	
	protected Map<String, Object> attributes;

	public Gummymodule(boolean autostart)
	{
		super(autostart);
		this.targets = new LinkedList<Processor>();
		this.parent = null;
		this.name = null;
		this.attributes = new HashMap<String, Object>();
	}
	
	public Gummymodule()
	{
		this(true);
	}
	
	private int depth()
	{
		return ((this.parent == null) ? 0 : (this.parent.depth()+1));
	}
	
	public void add_target(Processor target)
	{
		this.targets.add(target);
	}
	
	public void set_parent(Gummymodule parent)
	{
		this.parent = parent;
	}
	
	public Object get_parentattribute(String name) throws Exception
	{
		if (this.parent != null)
		{
			if (this.parent.attributes.containsKey(name))
			{
				return this.parent.attributes.get(name);
			}
			else throw (new Exception("attribute '" + name + "' is undefined in parent"));
		}
		else throw (new Exception("module does not have parent"));
	}
	
	public Gummymodule set_parentattribute(String name, Object value) throws Exception
	{
		if (this.parent != null)
		{
			if (this.parent.attributes.containsKey(name))
			{
				this.parent.attributes.put(name, value);
				return this;
			}
			else throw (new Exception("attribute '" + name + "' is undefined in parent"));
		}
		else throw (new Exception("module does not have parent"));
	}
	
	public Gummymodule set_name(String name)
	{
		this.name = name;
		return this;
	}
	
	protected void show_status(Gummyevent event)
	{
		if (Gummymodule.verbosity >= 1)
		{
			String message = "";
			for (int d = 0; d < this.depth()+1; d += 1) message += "\t";
			message += this.toString();
			message += " * ";
			message += event.toString();
			message += " ~ ";
			for (Processor target : this.targets) message += target.toString() + " ";
			System.out.println(message);
		}
	}
	
	public void spread(Gummyevent event)
	{
		if (! this.get_destructing())
		{
			/*
			if (Gummymodule.verbosity >= 1)
			{
				String message = "";
				for (int d = 0; d < this.depth(); d += 1) message += "\t";
				message += this.toString();
				message += " * ";
				message += event.toString();
				message += " ~ ";
				for (Processor target : this.targets) message += target.toString() + " ";
				System.out.println(message);
			}
			*/
			for (Processor target : this.targets) target.enqueue(event);
		}
	}
	
	public String toString()
	{
		String s = "";
		s += "[";
		// s += this.getClass().getSimpleName();
		// s += "|";
		if (this.name != null) s += (this.name);
		s += "]";
		return s;
	}
	
	public abstract void process(Gummyevent event);
}

