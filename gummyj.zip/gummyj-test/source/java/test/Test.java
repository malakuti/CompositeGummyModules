package test;

import backend.Environment;
import backend.Display;
import backend.Gummyevent;
import backend.Gummymodule;
import backend.GummymodulePrimitive;
import backend.GummymoduleComposite;

import generated.file.PremiumUsersEPAs;
import generated.file.OpenEvent;
import generated.file.ReadEvent;
import generated.file.WriteEvent;
import generated.file.CloseEvent;


class Test
{
	private String userID;
	private String fileID;
	private String userrole;
	private boolean valid;
	private Display display;
	
	public Test(String userID, String fileID, String userrole)
	{
		this.userID = userID;
		this.fileID = fileID;
		this.userrole = userrole;
		this.display = null;
	}
	public Test(String userID, String fileID) {this(userID, fileID, "premium");}
	public Test(String userID) {this(userID, "bar");}
	public Test() {this("foo");}
	
	private void begin()
	{
		Environment environment = Environment.get_instance();
		this.display = new Display(">>> releasing the following event to the public: ");
		Gummymodule module = new PremiumUsersEPAs(userID, fileID).set_name("fileprocessing");
		module.add_target(this.display);
		environment.insert(module);
		environment.start();
	}
	private void wait(int milliseconds)
	{
		Environment environment = Environment.get_instance();
		environment.wait(milliseconds);
	}
	private void end()
	{
		Environment environment = Environment.get_instance();
		environment.wait(1000);
		environment.stop();
		this.display.destruct();
	}
	
	private void send(Gummyevent base)
	{
		base.setAttribute("publisher", this.userID);
		base.setAttribute("userrole", this.userrole);
		base.setAttribute("fileID", this.fileID);
		Environment.get_instance().notify(base);
	}
	private void send_open() {this.send(new OpenEvent());}
	private void send_read() {this.send(new ReadEvent());}
	private void send_write() {this.send(new WriteEvent());}
	private void send_close() {this.send(new CloseEvent());}
	
	private void execute_regular(int count)
	{
		this.send_open();
		this.wait(200);
		for (int c = 0; c < count; c += 1)
		{
			this.send_read();
			this.wait(200);
			this.send_write();
			this.wait(200);
		}
		this.send_close();
	}
	private void execute_wrongorder()
	{
		this.send_open();
		this.wait(200);
		this.send_read();
		this.wait(200);
		this.send_close();
		this.wait(200);
		this.send_write();
	}
	private void execute_timeout(int count)
	{
		for (int c = 0; c < count; c += 1)
		{
			this.send_open();
			this.wait(200);
			this.send_read();
			this.wait(200);
			this.send_write();
			this.wait(2500);
			this.send_close();
			this.wait(500);
		}
	}
	
	public static void main(String[] args)
	{
		Environment.get_instance().verbosity = 1;
		Gummymodule.verbosity = 1;
		String usecase = (args.length >= 1) ? args[0] : "regular";
		
		Test test = new Test();
		test.begin();
		switch (usecase)
		{
			case "regular": {test.execute_regular(2); break;}
			case "wrongorder": {test.execute_wrongorder(); break;}
			case "timeout": {test.execute_timeout(5); break;}
			default: {System.err.println("unhandled usecase '" + usecase + "'"); break;}
		}
		test.end();
	}
}

