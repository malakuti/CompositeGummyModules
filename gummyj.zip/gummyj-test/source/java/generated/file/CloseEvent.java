package generated.file;

import backend.Gummyevent;

public class CloseEvent extends FileEvents
{
	
	public CloseEvent()
	{
		super();
	}
	
}

