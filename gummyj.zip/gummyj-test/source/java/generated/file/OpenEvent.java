package generated.file;

import backend.Gummyevent;

public class OpenEvent extends FileEvents
{
	public String get_mode()
	{
		return this.mode;
	}
	
	public void set_mode(String mode)
	{
		this.mode = mode;
		this.setAttribute("mode", mode);
	}
	
	private String mode;
	
	public OpenEvent()
	{
		super();
		this.setAttribute("mode", null);
	}
	
}

