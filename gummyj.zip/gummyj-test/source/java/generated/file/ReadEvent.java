package generated.file;

import backend.Gummyevent;

public class ReadEvent extends FileEvents
{
	public String get_content()
	{
		return this.content;
	}
	
	public void set_content(String content)
	{
		this.content = content;
		this.setAttribute("content", content);
	}
	
	private String content;
	
	public ReadEvent()
	{
		super();
		this.setAttribute("content", null);
	}
	
}

