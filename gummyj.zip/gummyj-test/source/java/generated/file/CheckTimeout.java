package generated.file;

import backend.Gummyevent;
import backend.Gummymodule;
import backend.GummymodulePrimitive;
import backend.GummymoduleEventmethod;

public class CheckTimeout extends GummymodulePrimitive
{
	
	private class CheckTimeout_open extends GummymoduleEventmethod
	{
		protected boolean condition(Gummyevent input) throws Exception
		{
			return (false || (input instanceof OpenEvent));
		}
		
		protected void action(Gummyevent input, Gummymodule self) throws Exception
		{
			if ((! opened))
			{
				opened = true;
				timer = init();
				while ((opened && (timer < ttl)))
					timer = update();
				if ((opened && (timer >= ttl)))
				{
					TimeoutEvent output = new TimeoutEvent();
					output.setAttribute("fileID", input.getAttribute("fileID"));
					output.setAttribute("userID", input.getAttribute("publisher"));
					output.setAttribute("opentime", timer);
					self.spread(output);
				}
			}
		}
		
		
		public CheckTimeout_open()
		{
			super();
			this.set_name("open");
		}
		
	}
	
	
	private class CheckTimeout_readwrite extends GummymoduleEventmethod
	{
		protected boolean condition(Gummyevent input) throws Exception
		{
			return ((false || (input instanceof ReadEvent)) || (input instanceof WriteEvent));
		}
		
		protected void action(Gummyevent input, Gummymodule self) throws Exception
		{
			timer = reset();
		}
		
		
		public CheckTimeout_readwrite()
		{
			super();
			this.set_name("readwrite");
		}
		
	}
	
	
	private class CheckTimeout_close extends GummymoduleEventmethod
	{
		protected boolean condition(Gummyevent input) throws Exception
		{
			return (false || (input instanceof CloseEvent));
		}
		
		protected void action(Gummyevent input, Gummymodule self) throws Exception
		{
			timer = reset();
			opened = false;
		}
		
		
		public CheckTimeout_close()
		{
			super();
			this.set_name("close");
		}
		
	}
	
	private long getCurrent()
	{
		return System.currentTimeMillis();
	}
	
	private long init()
	{
		last = getCurrent();
		return 0;
	}
	
	private long update()
	{
		return (getCurrent() - last);
	}
	
	private long reset()
	{
		last = getCurrent();
		return 0;
	}
	
	private boolean is_opened()
	{
		return opened;
	}
	
	private FileEvents processed;
	private boolean opened;
	private long last;
	private long timer;
	private int ttl = 2000;
	
	public CheckTimeout()
	{
		super();
		this.add_eventmethod(new CheckTimeout_open());
		this.add_eventmethod(new CheckTimeout_readwrite());
		this.add_eventmethod(new CheckTimeout_close());
	}
	
}

