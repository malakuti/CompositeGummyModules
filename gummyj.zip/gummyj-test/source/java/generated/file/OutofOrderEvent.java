package generated.file;

import backend.Gummyevent;

public class OutofOrderEvent extends Gummyevent
{
	public String get_fileID()
	{
		return this.fileID;
	}
	
	public void set_fileID(String fileID)
	{
		this.fileID = fileID;
		this.setAttribute("fileID", fileID);
	}
	
	public String get_userID()
	{
		return this.userID;
	}
	
	public void set_userID(String userID)
	{
		this.userID = userID;
		this.setAttribute("userID", userID);
	}
	
	private String fileID;
	private String userID;
	
	public OutofOrderEvent()
	{
		super();
		this.setAttribute("fileID", null);
		this.setAttribute("userID", null);
	}
	
}

