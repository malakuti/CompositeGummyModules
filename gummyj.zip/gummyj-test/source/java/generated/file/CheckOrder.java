package generated.file;

import backend.Gummyevent;
import backend.Gummymodule;
import backend.GummymodulePrimitive;
import backend.GummymoduleEventmethod;

public class CheckOrder extends GummymodulePrimitive
{
	
	private class CheckOrder_check extends GummymoduleEventmethod
	{
		protected boolean condition(Gummyevent input) throws Exception
		{
			return (false || (input instanceof FileEvents));
		}
		
		protected void action(Gummyevent input, Gummymodule self) throws Exception
		{
			if ((false || (input instanceof OpenEvent)))
			{
				if ((! opened))
				{
					opened = true;
				}
				else
				{
					OutofOrderEvent output = new OutofOrderEvent();
					output.setAttribute("fileID", input.getAttribute("fileID"));
					output.setAttribute("userID", input.getAttribute("publisher"));
					self.spread(output);
				}
			}
			else
			{
				if (((false || (input instanceof ReadEvent)) || (input instanceof WriteEvent)))
				{
					if ((! opened))
					{
						OutofOrderEvent output = new OutofOrderEvent();
						output.setAttribute("fileID", input.getAttribute("fileID"));
						output.setAttribute("userID", input.getAttribute("publisher"));
						self.spread(output);
					}
				}
				else
				{
					if ((false || (input instanceof CloseEvent)))
					{
						if ((! opened))
						{
							OutofOrderEvent output = new OutofOrderEvent();
							output.setAttribute("fileID", input.getAttribute("fileID"));
							output.setAttribute("userID", input.getAttribute("publisher"));
							self.spread(output);
						}
						else
						{
							opened = false;
						}
					}
				}
			}
		}
		
		
		public CheckOrder_check()
		{
			super();
			this.set_name("check");
		}
		
	}
	
	private boolean opened = false;
	
	public CheckOrder()
	{
		super();
		this.add_eventmethod(new CheckOrder_check());
	}
	
}

