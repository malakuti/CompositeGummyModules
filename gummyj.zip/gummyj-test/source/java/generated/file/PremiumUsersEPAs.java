package generated.file;

import backend.GummymoduleComposite;
import backend.GummymoduleAggregator;

public class PremiumUsersEPAs extends GummymoduleComposite
{
	private Long counter = new Long(0);
	
	public PremiumUsersEPAs(String userID, String fileID)
	{
		super();
		this.attributes.put("counter", new Long(0));
		this.add_selector(new FilterUsers(userID, fileID).set_name("userselection"));
		this.add_reactor(new CheckOrder().set_name("orderchecker"));
		this.add_reactor(new CheckTimeout().set_name("timeoutchecker"));
		this.add_publisher(new GummymoduleAggregator(new OutofOrderEvent()).set_name("ordererror"));
		this.add_publisher(new FilterEvents().set_name("timeouterror"));
	}
	
}

