package generated.file;

import backend.Gummyevent;

public class TimeoutEvent extends Gummyevent
{
	public String get_fileID()
	{
		return this.fileID;
	}
	
	public void set_fileID(String fileID)
	{
		this.fileID = fileID;
		this.setAttribute("fileID", fileID);
	}
	
	public String get_userID()
	{
		return this.userID;
	}
	
	public void set_userID(String userID)
	{
		this.userID = userID;
		this.setAttribute("userID", userID);
	}
	
	public int get_opentime()
	{
		return this.opentime;
	}
	
	public void set_opentime(int opentime)
	{
		this.opentime = opentime;
		this.setAttribute("opentime", opentime);
	}
	
	private String fileID;
	private String userID;
	private int opentime;
	
	public TimeoutEvent()
	{
		super();
		this.setAttribute("fileID", null);
		this.setAttribute("userID", null);
		this.setAttribute("opentime", null);
	}
	
}

