package generated.file;

import backend.Gummyevent;
import backend.Gummymodule;
import backend.GummymodulePrimitive;
import backend.GummymoduleEventmethod;

public class FilterUsers extends GummymodulePrimitive
{
	
	private class FilterUsers_filter extends GummymoduleEventmethod
	{
		protected boolean condition(Gummyevent input) throws Exception
		{
			return ((((false || (input instanceof FileEvents)) && (input.getAttribute("publisher") == userID)) && (input.getAttribute("userrole") == "premium")) && (input.getAttribute("fileID") == fileID));
		}
		
		protected void action(Gummyevent input, Gummymodule self) throws Exception
		{
			self.spread(input);
		}
		
		
		public FilterUsers_filter()
		{
			super();
			this.set_name("filter");
		}
		
	}
	
	private String userID;
	private String fileID;
	
	public FilterUsers(String userID, String fileID)
	{
		super();
		this.userID = userID;
		this.fileID = fileID;
		this.add_eventmethod(new FilterUsers_filter());
	}
	
}

