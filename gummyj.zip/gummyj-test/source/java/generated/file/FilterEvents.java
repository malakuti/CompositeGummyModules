package generated.file;

import backend.Gummyevent;
import backend.Gummymodule;
import backend.GummymodulePrimitive;
import backend.GummymoduleEventmethod;

public class FilterEvents extends GummymodulePrimitive
{
	
	private class FilterEvents_filter extends GummymoduleEventmethod
	{
		protected boolean condition(Gummyevent input) throws Exception
		{
			return (false || (input instanceof TimeoutEvent));
		}
		
		protected void action(Gummyevent input, Gummymodule self) throws Exception
		{
			self.set_parentattribute("counter", (((Long) (self.get_parentattribute("counter"))) + 1));
			System.out.println((("+ " + self.get_parentattribute("counter")) + ". timeout"));
			if ((((Long) (self.get_parentattribute("counter"))) > 3))
			{
				self.spread(input);
			}
		}
		
		
		public FilterEvents_filter()
		{
			super();
			this.set_name("filter");
		}
		
	}
	
	
	public FilterEvents()
	{
		super();
		this.add_eventmethod(new FilterEvents_filter());
	}
	
}

