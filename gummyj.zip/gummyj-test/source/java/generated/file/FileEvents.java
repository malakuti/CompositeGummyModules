package generated.file;

import backend.Gummyevent;

public class FileEvents extends Gummyevent
{
	public String get_fileID()
	{
		return this.fileID;
	}
	
	public void set_fileID(String fileID)
	{
		this.fileID = fileID;
		this.setAttribute("fileID", fileID);
	}
	
	public String get_userrole()
	{
		return this.userrole;
	}
	
	public void set_userrole(String userrole)
	{
		this.userrole = userrole;
		this.setAttribute("userrole", userrole);
	}
	
	private String fileID;
	private String userrole;
	
	public FileEvents()
	{
		super();
		this.setAttribute("fileID", null);
		this.setAttribute("userrole", null);
	}
	
}

