== Building the project == 
	execute "ant clear generate build pack" (ommit the "generate"-part if the generator-binary does not work on your system)

== Processing usecases ==
	First build the project and then:
	* usecase "regular": execute "ant run-regular"
	* usecase "wrongorder": execute "ant run-wrongorder"
	* usecase "timeout": execute "ant run-timeout"

